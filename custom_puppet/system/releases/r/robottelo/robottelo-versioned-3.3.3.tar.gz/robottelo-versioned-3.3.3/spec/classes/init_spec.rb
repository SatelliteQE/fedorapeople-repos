require 'spec_helper'
describe 'generic_1' do

  context 'with defaults for all parameters' do
    it { should contain_class('generic_1') }
  end
end
