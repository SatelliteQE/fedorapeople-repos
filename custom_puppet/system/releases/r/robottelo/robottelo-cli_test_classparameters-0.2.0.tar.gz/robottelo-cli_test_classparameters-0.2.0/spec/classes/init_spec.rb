require 'spec_helper'
describe 'cli_test_classparameters' do

  context 'with defaults for all parameters' do
    it { should contain_class('cli_test_classparameters') }
  end
end
