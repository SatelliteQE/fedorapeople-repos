require 'spec_helper'
describe 'ui_test_variables' do

  context 'with defaults for all parameters' do
    it { should contain_class('ui_test_variables') }
  end
end
