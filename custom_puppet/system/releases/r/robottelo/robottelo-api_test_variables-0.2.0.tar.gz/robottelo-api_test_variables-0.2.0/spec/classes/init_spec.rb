require 'spec_helper'
describe 'api_test_variables' do

  context 'with defaults for all parameters' do
    it { should contain_class('api_test_variables') }
  end
end
