require 'spec_helper'
describe 'generic_3' do

  context 'with defaults for all parameters' do
    it { should contain_class('generic_3') }
  end
end
