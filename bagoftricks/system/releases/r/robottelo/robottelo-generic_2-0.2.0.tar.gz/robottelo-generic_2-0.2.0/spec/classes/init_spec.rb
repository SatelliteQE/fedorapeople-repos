require 'spec_helper'
describe 'generic_2' do

  context 'with defaults for all parameters' do
    it { should contain_class('generic_2') }
  end
end
