##2014-03-04, Supported Release 0.1.5
###Summary
This is a supported release.

####Known Bugs

* The version is `0.x` but should be considered a `1.x` for semantic versioning purposes.

---

###2014-02-07, Release 0.1.4

 * (PUP-1578) Workaround ruby bug that can prevent ruby.exe from exiting

###2013-09-27, Release 0.1.2

 * (PE-1669) Never load sample.pp in production

###2013-09-27, Release 0.1.1

 * (FM-105) Only manage reboot resources on systems where shutdown.exe exists
 * (FM-106) Module does not work on Windows 2003
 * (PP-433) Update description in init.pp

###2013-09-17, Release 0.1.0

Initial release of the reboot module
