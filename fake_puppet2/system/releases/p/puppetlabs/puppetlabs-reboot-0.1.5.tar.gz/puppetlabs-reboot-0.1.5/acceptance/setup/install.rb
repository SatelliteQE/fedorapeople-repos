test_name "Installing Puppet Enterprise" do
  install_pe
end
